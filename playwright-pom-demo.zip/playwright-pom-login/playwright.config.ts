import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests',

  reporter: [['html', { open: 'never' }]],

  use: {
    baseURL: 'https://www.saucedemo.com',
    headless: false,
    video: 'on',
    screenshot: 'only-on-failure',
    actionTimeout: 10000,
    navigationTimeout: 20000 // 20 seconds
  }
});

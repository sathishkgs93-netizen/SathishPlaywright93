# Playwright POM Login Automation

## Setup
npm install
npx playwright install

## Run Tests
npm test
npm run test:ui

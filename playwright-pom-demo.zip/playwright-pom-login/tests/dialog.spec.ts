// import { test, expect } from '@playwright/test';
// import { LoginPage } from '../pages/LoginPage';

// test.describe('SauceDemo Login Test', () => {
//     test('to test alert', async ({ page }) => {
//         await page.goto('https://demoqa.com/alerts');

//         page.on('dialog', async dialog => {
//             console.log(`Dialog message: ${dialog.message()}`);
//             await dialog.accept('Playwright');
//         });

//         await page.locator('#promtButton').click();
//         await page.waitForTimeout(2000);

//     });
//     test('to test frames', async ({ page }) => {
//         await page.goto('https://demoqa.com/frames');
//         const frame = page.frameLocator('#frame1');
//         const sampleHeading = await frame.locator('#sampleHeading').textContent();
//         console.log(sampleHeading);
//         expect(frame.locator('#sampleHeading')).toHaveText('This is a sample page');

//     });
//     test('to test nested frames', async ({ page }) => {
//         await page.goto('https://demoqa.com/nestedframes');
//         const parentFrame = page.frameLocator('#frame1');
//         const childFrame = parentFrame.frameLocator('iframe');

//         const childFrameContent = await childFrame.locator('p').textContent();
//         console.log(childFrameContent);
//         expect(childFrame.locator('p')).toHaveText('Child Iframe');
//     });

//     test.only('GET posts', async ({ request }) => {

//         const response = await request.get('https://jsonplaceholder.typicode.com/posts/1');

//         expect(response.status()).toBe(200);

//         const body = await response.json();

//         console.log(body);

//         expect(body.id).toBe(1);
//     });



// });
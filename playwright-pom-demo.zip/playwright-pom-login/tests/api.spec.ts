// import { test, expect } from '@playwright/test';

// test.describe('API tests', () => {
//     //     test('GET API tests', async ({ request }) => {
//     //         const response = await request.get('https://jsonplaceholder.typicode.com/posts/3');
//     //         expect(response.status()).toBe(200);

//     //         const body = await response.json();
//     //         console.log(body);
//     //         console.log(`Title: ${body.title}`);
//     //         expect(body.id).toBe(3);

//     //     });

//     //     test('POST API tests', async ({ request }) => {
//     //         const payload = {
//     //             title: 'Test Post',
//     //             body: 'Test Body',
//     //             userId: 1
//     //         };

//     //         const response = await request.post('https://jsonplaceholder.typicode.com/posts', { data: payload });
//     //         expect(response.status()).toBe(201);
//     //         const responseBody = await response.json();
//     //         console.log(responseBody);
//     //         console.log(`Created Post ID: ${responseBody.id}`);
//     //     });

//     // test('Log API request', async ({ page }) => {

//     //     await page.route('**/posts/3', async (route, request) => {

//     //         console.log('URL:', request.url());
//     //         console.log('Method:', request.method());

//     //         await route.continue();
//     //     });

//     //     await page.goto('https://jsonplaceholder.typicode.com');
//     // });

//     // // URL: https://reqres.in/api/users?page=2
//     // // Method: GET
//     // // https://dummyjson.com/products/1


//     // test('Mock product API response', async ({ page }) => {

//     //     await page.route('**/products/1', async route => {

//     //         await route.fulfill({
//     //             status: 200,
//     //             contentType: 'application/json',
//     //             body: JSON.stringify({
//     //                 id: 1,
//     //                 title: "Mocked iPhone",
//     //                 price: 99999
//     //             })
//     //         });

//     //     });

//     //     const response = await page.goto('https://dummyjson.com/products/1');

//     //     await page.waitForTimeout(5000);

//     // });

//     test('take screenshot of website', async ({ page }) => {
//         await page.goto('https://www.saucedemo.com');
//         // await page.waitForLoadState('networkidle');
//         // await expect(page).toHaveScreenshot('API_Screenshot.png', {
//         //     maxDiffPixels: 100,
//         //     animations: 'disabled'
//         // });

//         const screenshot = await page.screenshot({ path: 'screenshot.png', fullPage: true })
//         await expect(screenshot).toMatchSnapshot('screenshot.png')
//     });

// });
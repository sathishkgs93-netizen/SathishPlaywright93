import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ProductPage } from '../pages/ProductPage';

test('Login and logout test', async ({ page }) => {
  const loginPage = new LoginPage(page)
  const productPage = new ProductPage(page)

  await loginPage.goto()
  await loginPage.login("standard_user", "secret_sauce");
  await expect(page).toHaveURL('/inventory.html')

  console.log(await productPage.getProductTitle());
  await productPage.logout();

  await loginPage.login('standard_user', 'secret_sauce');
});
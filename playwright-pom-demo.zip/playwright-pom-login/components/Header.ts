import { Page, Locator } from '@playwright/test';

export class Header {
    readonly page: Page;
    readonly logo: Locator;
    readonly cartIcon: Locator;
    readonly menuButton: Locator;

    constructor(page: Page) {
        this.page = page;
        this.logo = page.locator('.app_logo');
        this.cartIcon = page.locator('.shopping_cart_link');
        this.menuButton = page.locator('#react-burger-menu-btn');
    }

    async clickCart() {
        await this.cartIcon.click();
    }

    async openMenu() {
        await this.menuButton.click();
    }
}
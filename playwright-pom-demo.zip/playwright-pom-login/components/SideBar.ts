import { Page, Locator } from '@playwright/test';

export class SideBar {
    readonly page: Page;
    readonly logoutLink: Locator;

    constructor(page: Page) {
        this.page = page;
        this.logoutLink = page.locator('#logout_sidebar_link');
    }

    async logout() {
        await this.logoutLink.click();
    }
}